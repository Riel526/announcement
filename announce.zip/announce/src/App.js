import React, {useState}from 'react'


const App = ()=>{



  const [value, setValue] = useState()

  const [announcement, setAnnouncement]=useState([
    {
      id:1,
      announcement: "Hello willers" 
    },
    {
      id:2,
      announcement: "wala lang whahaah"
    }

  ])


const addTextChange = (event) => {
  setValue(event.target.value)
}


const addHandler = ()=>{
  let newAnnouncement = {id: announcement.length+1, announcement: value}
  let array = announcement.concat(newAnnouncement)
  setAnnouncement(array)
  }



const removeHandler = (announce)=>{ 
  const newAnnouncement = announcement.filter(announces => announces.id !== announce.id)
  setAnnouncement(newAnnouncement)
}

return(
<div>
<input 
    type = "text"
    name ="addText"
    onChange ={addTextChange}
    />


  <button onClick={addHandler}>Add announcement</button>


<h1>Announcement: </h1>
{
  announcement.map((announce)=>{
    return(
      <li key = {announce.id}>
        {announce.announcement}
        <button onClick={()=>{removeHandler(announce)}}>x</button>
      </li>
    )
    
  })
}


</div>
)
}

export default App;